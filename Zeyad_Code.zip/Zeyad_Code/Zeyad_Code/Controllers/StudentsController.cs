﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Zeyad_Code.Data;
using Zeyad_Code.Models;

namespace Zeyad_Code.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly Database_context _context;

        public StudentsController(Database_context context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult GetAllStudents()
        {
            var students =  _context.Students.ToList();

            return Ok(students);
        }

        [HttpGet("{Id:int}")]
        public ActionResult<Student> GetStudentById(int id)
        {
            var student = _context.Students.Find(id);

            if (student == null)
            {
                return NotFound();
            }

            return Ok(student);
        }
    }
}