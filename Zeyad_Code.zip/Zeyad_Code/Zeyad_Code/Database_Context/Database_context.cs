﻿using Microsoft.EntityFrameworkCore;
using Zeyad_Code.Models;

namespace Zeyad_Code.Data
{
    public class Database_context : DbContext
    {
        public DbSet<Department> Departments { get; set; }

        public DbSet<Teacher> Teachers { get; set; }

        public DbSet<Subject> Subjects { get; set; }

        public DbSet<ClassRoom> ClassRooms { get; set; }

        public DbSet<Student> Students { get; set; }

        public DbSet<Enrollment> Enrollments { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder.UseSqlServer(
            "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Zeyad_Code;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False"));
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>()
                .HasMany(d => d.Teachers)
                .WithOne(t => t.Department)
                .HasForeignKey(t => t.DepartmentId);


            modelBuilder.Entity<Teacher>()
                .HasMany(t => t.Subjects)
                .WithOne(s => s.Teacher)
                .HasForeignKey(s => s.TeacherId);


            modelBuilder.Entity<ClassRoom>()
                .HasMany(c => c.Students)
                .WithOne(s => s.ClassRoom)
                .HasForeignKey(s => s.ClassRoomId);


            modelBuilder.Entity<Student>()
                .HasMany(s => s.Enrollments)
                .WithOne(e => e.Student)
                .HasForeignKey(e => e.StudentId);


            modelBuilder.Entity<Subject>()
                .HasMany(s => s.Enrollments)
                .WithOne(e => e.Subject)
                .HasForeignKey(e => e.SubjectId);


            modelBuilder.Entity<Department>().HasData(
                new Department
                {
                    Id = 1,
                    Name = "Computer Science",
                    Description = "Computer Science Department"
                }
            );


            modelBuilder.Entity<Teacher>().HasData(
                new Teacher
                {
                    Id = 1,
                    FirstName = "Ahmed",
                    LastName = "Mohamed",
                    Email = "ahmed@gmail.com",
                    PhoneNumber = "01000000000",
                    Salary = 10000,
                    DepartmentId = 1
                }
            );


            modelBuilder.Entity<Subject>().HasData(
                new Subject
                {
                    Id = 1,
                    Name = "Programming",
                    Description = "Programming Subject",
                    MaxGrade = 100,
                    TeacherId = 1
                }
            );


            modelBuilder.Entity<ClassRoom>().HasData(
                new ClassRoom
                {
                    Id = 1,
                    Name = "Class A",
                    GradeLevel = 1,
                    Capacity = 30
                }
            );


            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    Id = 1,
                    FirstName = "Zeyad",
                    LastName = "Mohamed",
                    Email = "zeyad@gmail.com",
                    PhoneNumber = "01100000000",
                    DateOfBirth = new DateOnly(2009, 6, 1),
                    ClassRoomId = 1
                }
            );


            modelBuilder.Entity<Enrollment>().HasData(
                new Enrollment
                {
                    Id = 1,
                    StudentId = 1,
                    SubjectId = 1,
                    EnrollmentDate = new DateTime(2026, 9, 1),
                    Grade = 90
                }
            );
        }
    }
}