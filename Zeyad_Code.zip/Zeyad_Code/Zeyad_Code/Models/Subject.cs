﻿using System.ComponentModel.DataAnnotations;

namespace Zeyad_Code.Models
{
    public class Subject
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = null!;

        [MaxLength(500)]
        public string? Description { get; set; }

        [Required]
        [Range(1, 100)]
        public int MaxGrade { get; set; }


        public int TeacherId { get; set; }

        public Teacher Teacher { get; set; } = null!;

        public ICollection<Enrollment> Enrollments { get; set; }
            = new List<Enrollment>();
    }
}