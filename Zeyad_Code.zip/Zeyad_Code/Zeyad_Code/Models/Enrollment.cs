﻿using System.ComponentModel.DataAnnotations;

namespace Zeyad_Code.Models
{
    public class Enrollment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int StudentId { get; set; }

        public Student Student { get; set; } = null!;

        [Required]
        public int SubjectId { get; set; }

        public Subject Subject { get; set; } = null!;


        [Required]
        public DateTime EnrollmentDate { get; set; }

        [Range(0, 100)]
        public decimal Grade { get; set; }
    }
}