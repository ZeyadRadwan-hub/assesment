﻿using System.ComponentModel.DataAnnotations;

namespace Zeyad_Code.Models
{
    public class Teacher
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; } = null!;

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; } = null!;

        [Required]
        [EmailAddress]
        [MaxLength(150)]
        public string Email { get; set; } = null!;

        [Phone]
        [MaxLength(20)]
        public string? PhoneNumber { get; set; }

        [Required]
        [Range(0, double.MaxValue)]
        public decimal Salary { get; set; }

        public int DepartmentId { get; set; }

        public Department Department { get; set; } = null!;

        public ICollection<Subject> Subjects { get; set; }
            = new List<Subject>();
    }
}