﻿using System.ComponentModel.DataAnnotations;

namespace Zeyad_Code.Models
{
    public class ClassRoom
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; } = null!;

        [Required]
        [Range(1, 12)]
        public int GradeLevel { get; set; }

        [Required]
        [Range(1, 100)]
        public int Capacity { get; set; }

        public ICollection<Student> Students { get; set; }
            = new List<Student>();
    }
}